# Luísa Costa — Portfolio (YouTube-style)

A portfolio site styled like a YouTube channel page in dark mode: banner, avatar, channel info, and a "Videos" grid where each thumbnail is a project. Clicking a thumbnail opens a popup (background blurred, and the popup itself scrolls smoothly if there's a lot of content) showing the full project write-up — closable with the X, by clicking outside it, or pressing Escape.

Every file (`index.html`, `styles.css`, `script.js`) is commented so you can find and change things easily — colors are all defined as CSS variables at the top of `styles.css`.

## Before you publish

1. **Images** — this build links directly to the images on Carrd's CDN (`luisadesigns.carrd.co/assets/images/...`) so the site works immediately. For full independence from Carrd, download those images and swap the `src` paths in `index.html` to a local `assets/` folder instead.
2. **LinkedIn link** — the LinkedIn button in the `.channel-buttons` block in `index.html` points to `https://www.linkedin.com/` as a placeholder. Replace it with your real profile URL.
3. **CV button** — points to `cv.pdf`. Add your actual CV file to this folder with that name, or change the `href` to wherever it lives.
4. **`preview.html`** is just for quickly viewing the site in one file (CSS/JS inlined) — don't publish this one, use the three separate files below instead so they stay easy to maintain.

## Project count auto-updates

The "@luisacosta · X projects" text in the header updates itself automatically — `script.js` counts however many `.card` thumbnails exist in the grid and fills that number in when the page loads. Add or remove a project and the count follows along; you never need to edit it by hand. This runs entirely in the visitor's browser (not on a server), so it works fine on GitHub Pages.

## How each project's popup works

Each project has two matching pieces in `index.html`:

- A **`<button class="card" data-modal="modal-1">`** in the `.grid` section — this is the visible thumbnail.
- A **`<template id="modal-1">`** further down the page — this holds everything shown inside its popup (title, badge, images, text, links). Nothing inside a `<template>` is visible on the page itself; `script.js` clones it into the popup only when its matching card is clicked.

**To add more content to an existing project's popup** (more images, a video, more paragraphs, a link), open its `<template>` and look for the commented placeholder block near the bottom — copy any of these lines/blocks above that comment and fill in the real URL/text:

```html
<img class="modal-media" src="PASTE-IMAGE-URL-HERE.jpg" alt="Describe this image">

<video class="modal-media" controls>
  <source src="PASTE-VIDEO-URL-HERE.mp4" type="video/mp4">
  Your browser does not support the video tag.
</video>

<p class="modal-desc">Another paragraph goes here.</p>

<a class="modal-link" href="PASTE-URL-HERE" target="_blank" rel="noopener">Link text</a>
```

There's no length limit — the popup scrolls internally.

**To embed a YouTube video**, copy this block (it's already sitting in the 2D Platformer template, ready for a real video ID):

```html
<div class="modal-video-wrap">
  <iframe src="https://www.youtube.com/embed/YOUR_VIDEO_ID_HERE" title="YouTube video player" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
</div>
```

Get the video ID from the normal watch link — `youtube.com/watch?v=`**`THIS_PART`**`` — and drop it in place of `YOUR_VIDEO_ID_HERE`. The wrapper keeps a 16:9 shape at any width, so it scales with the popup automatically.

**To add a whole new project**, look for the big `HOW TO ADD A NEW PROJECT` comment block right above the `Projects` grid in `index.html`. It contains a ready-to-use card + template pair — copy it out, delete the `<!--`/`-->` around it, paste it into `.grid`, give it a new id (e.g. `modal-4`), and fill in your content.

## Publish on GitHub Pages

1. Create a new repository on GitHub (e.g. `luisa-portfolio`).
2. Push these files (`index.html`, `styles.css`, `script.js`) to the repo's root (or to a `docs/` folder — just adjust the Pages setting to match).
3. In the repo, go to **Settings → Pages**.
4. Under "Build and deployment", set **Source** to "Deploy from a branch", pick your branch (usually `main`) and the folder (`/root` or `/docs`).
5. Save. GitHub will give you a URL like `https://yourusername.github.io/luisa-portfolio/` within a minute or two.

## Structure

- `index.html` — banner, channel header, the project grid (cards), the "how to add a project" copy-paste block, each project's `<template>` (its popup content), and the popup shell markup
- `styles.css` — color variables at the top, then banner/header/grid/popup styling, all commented
- `script.js` — clones the right `<template>` into the popup when a card is clicked, closes it via the X button, clicking outside, or Escape
- `preview.html` — same site as one self-contained file, for quick previewing only
